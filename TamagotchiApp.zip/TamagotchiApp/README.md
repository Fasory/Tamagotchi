---
* Groupe : BIDAULT Julie-Amélie, HAGUET Victor, BOUQUET Clément,
           BRZUSTOWSKI Matthias, CASANOVA Arthur

* Création : 29/09/2021
* Version : 2.0.0
* Description : Projet Tamagotchi pour l'UE Génie Logiciel
* Lien du projet : https://github.com/Fasory/Tamagotchi
---
